# Handoff: Parea album page — photo-first (2b + 2c + 2d)

## Overview
A restructure of the album (event) page — `apps/web/app/event/[id]/page.tsx` → `EventView.tsx`. Today roughly a third of the width is a permanently open chat column while the photographs sit as isolated 150px squares in a wide empty area, and the head carries `@handle · caption` on the title's own line. Three tabs replace that split: **Photos** (default), **Conversation**, **People**. Photos take the full content width as a masonry gallery at natural aspect ratio; conversation stays one tab away rather than competing with the pictures.

The rule the design follows: **photos occupy the page, people give them context, conversation stays available without competing with them.**

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes of intended look and behaviour, not production code to copy. Recreate them in `apps/web` using its existing environment: Next.js App Router, server components, class-based CSS in `app/globals.css`, and the existing components (`EventView`, `Thread`, `PhotoTile`, `PhotoLightbox`, `Menu`, `Faces`, `ShareEvent`, `useUploads`). The prototypes use inline styles only because the prototyping environment requires it; in the codebase these belong as classes and tokens in `globals.css`, as today.

## Fidelity
**High-fidelity.** Colours, type sizes, radii, gaps and paddings are final and listed below. Photographs and avatars are striped gradient placeholders — the only thing to substitute.

## Screens / Views

### Shared shell — header and tabs (all three files)
Replaces `.event-head` (today: sticky 78px bar, host face 38px, `h1` 20px, `.event-caption`, `.event-people`, then icon-only share / filled `+` / `···`).

**Header**, `padding:18px 28px 0` on the warm page (no card, no bottom border of its own — the tab strip's `1px solid #eee7dd` is the only rule):
- A back affordance at the left: `‹`, 34px hit area, `color:#5b6472`, `margin-left:-6px` so the glyph optically aligns with the title.
- Row 1: `h1` — `25px/700; letter-spacing:-.02em; line-height:1.15`, the album name. Right-aligned in the same row, the action group (below).
- Row 2: metadata, `13.5px; color:#8a8378`, `margin-top:5px` — `April 15, 2026 · At home · 2 people · 2 photos`. Event date (not `ago()`), place prefixed naturally ("At home", or omitted when there is none), member count, photo count. This is the only place the photo count appears on screen.
- Row 3: faces + creator, `margin-top:9px` — overlapping 24px avatars (`margin-left:-8px`, `box-shadow:0 0 0 2px #fbf8f4`), max 4 then a `+1` chip in `#efe9e0`; then `Created by **Demetri**` at `13px; color:#5b6472` with the name `#14171c/500`.
- Row 4 (optional): the host's own line — `a movie`, `13.5px; color:#5b6472; margin-top:8px`. It is a description, never on the title's line, and the `@handle` does **not** appear in the header at all (it lives on People and on profiles).

**Actions** — words, not glyphs, `gap:8px`:
- `Add photos` — filled, `background:#4e63a8; color:#fff; padding:10px 16px; 14.5px/600; radius:10px`. Keeps today's mechanism: a `<label for>` over the hidden multi-file input, `Adding…` while `uploads.running`, and it only renders when `uploadsOpen && session.account`.
- `Invite` — outlined, `border:1px solid #e4ded4; padding:10px 15px`. Opens `ShareEvent` (today's icon-only share button).
- `↓` Download — 36×36, same outline, `radius:10px`; the popover keeps today's items (Download all / Download all as JPEG / Select images).
- `···` More — 36×36, same outline, `color:#5b6472`; keeps Manage event and the waiting badge.

**Tabs** — `display:flex; gap:26px; margin-top:18px; border-bottom:1px solid #eee7dd`; each tab `padding:0 2px 11px; 14.5px`, inactive `#5b6472`, active `#14171c/600` with `border-bottom:2px solid #4e63a8; margin-bottom:-1px`. Order: **Photos · Conversation · People**. Default Photos. Conversation carries an unread count when there is one — a pill, `padding:1px 7px; radius:999px; background:#eceffb; color:#3f5498; 11.5px/700` — from the existing per-browser `pa_thread_seen_<eventId>` unread computation. People carries no count (the header already says how many).

Tab state belongs in the URL as `?tab=conversation|people` (Photos is the bare URL) so a link to the roster is shareable and Back works; today's thread tabs are client-only state, and the `pa_thread_folded` preference is no longer needed — delete it.

### `2b-photos-masonry.html` — Photos (default tab)
Full content width, `padding:22px 28px 34px`. No thread column, so the gallery is the page.

**Section head** for arrivals — replaces `.section-head`: `JUST ADDED` at `12px/600; letter-spacing:.06em; uppercase; color:#8a8378`, the caption beside it (`Maya, 8 minutes ago` — existing `freshCaption`), a `1px #eee7dd` rule filling the row, then the arriving pill at the right: `padding:5px 11px; radius:999px; background:#eaf5ef; color:#3d6a55; 12px/600` with a 6px `#a5dcc6` dot on the existing `@keyframes pulse`. Keep `EARLIER` as a second section head of the same construction when both exist.

**Gallery** — masonry: `display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:12px; align-items:start`, each column a `flex-direction:column; gap:12px` stack. Photos keep their natural aspect ratio (`height:auto`, `width:100%`); the prototype's fixed heights stand in for real ratios. Tiles: `border-radius:14px; overflow:hidden`, no border, no shadow. Distribute by shortest-column-first over the ordered photo list so reading order stays chronological down each column. Columns: 4 at ≥1200px content width, 3 at ≥900, 2 at ≥600, 1 below.

**First tile is the contribute affordance** — `height:210px; border-radius:14px; border:1px dashed #d9d1c4; background:rgba(255,255,255,.5)`, centred column with `gap:10px`: the three-circle mark as 24px lenses (`#ffb3b8`, `#9db2f0`, `#a5dcc6`, overlapped `-8px`), **Add your photos** at `15.5px/600`, then `Everyone here can contribute.` at `12.5px; color:#5b6472`. It is the same control as the header button (label over the same input) and it stays first even when the album is full.

**Hover state** (shown on the tall tile in column 2): a scrim `linear-gradient(180deg, rgba(20,23,28,.42), rgba(20,23,28,0) 42%, rgba(20,23,28,.55))` over the photo, then
- top-left a select checkbox, 22×22, `radius:6px; border:1.5px solid rgba(255,255,255,.9); background:rgba(255,255,255,.18)` — checking one enters today's selection mode (`picked` Set) and keeps the existing footer bar;
- top-right `↓` and `···`, 30×30, `radius:8px; background:rgba(255,255,255,.92)` — download this one, and the more menu (which is where report/remove live, reachable per the existing guideline-1.2 note);
- bottom-left the contributor: 24px avatar with a `rgba(255,255,255,.85)` ring, name `13px/600`, then `Added 8m ago` at `12.5px; opacity:.85` — all `#fff`.

Hover shows on `:hover` and `:focus-within`; on touch the overlay's chrome appears on first tap and the second tap opens the lightbox. **No likes, reactions or counts on photos.** Keep `PhotoTile`'s failure behaviour (the slot stays, `Not available`, still a button) — with the masonry, a failed tile keeps a 3:2 box so the column does not collapse.

Clicking a tile (outside the overlay controls, and when not selecting) opens the existing `PhotoLightbox`. Photo comments (`PhotoComments.tsx`) stay in the lightbox; they are not the event conversation.

### `2c-people.html` — People
Column, `padding:26px 28px 34px; max-width:820px`.

- Head: `2 people have joined` at `19px/700`, then `Invite everyone who was there so the album has every perspective.` at `13.5px; color:#5b6472; max-width:460px`. An `Invite` filled button sits opposite it.
- Rows, `padding:13px 4px`, separated by `1px solid #f2ece3` (no card): 44px avatar (photo, or lens colour + initial), then name `15.5px/600` with the handle beside it at `12.5px; color:#8a8378`, and under it the contribution — `2 photos added` / `Nothing added yet` at `12.5px; color:#5b6472`.
- Role pill at the right, `padding:4px 10px; radius:999px; 11.5px/600`: Creator `background:#f5ece2; color:#7d5230`; Contributor `background:#eaf5ef; color:#3d6a55`; Viewer `background:#eef1f4; color:#5b6472`; Invited `background:#fbf3e8; color:#8a6a3a`. An invited-but-not-joined row is dimmed: dashed 44px circle, name in `#5b6472`, second line `Sent 2 days ago · not opened`, plus a `Remind` outlined 12.5px button.
- Foot: a soft panel, `padding:16px 18px; radius:14px; background:rgba(255,255,255,.66)` — the three-circle mark at 26px, `Anyone with the link can add photos — no account needed to look.`, and a `Copy link` outlined button.

Data: today's `members` (from `membersOf`) plus per-person photo counts (today's `people` / `contributorsOf`) joined by actor, plus invite state and sent-at from `src/invites.ts`. Role comes from the event's access policy — creator, whoever may `contribute`, everyone else viewer. Only render Remind/roles a viewer is allowed to see; management still lives on Manage.

### `2d-conversation.html` — Conversation
Column, `padding:34px 28px 30px; max-width:760px`, event-level (not per-photo).

- **Empty state**, left-aligned, vertically centred in the space above the composer: the three-circle mark at 48px, `Talk about the moment` at `21px/700`, then `Ask for a missing photo, share what happened or let everyone know when you've added yours.` at `14.5px; color:#5b6472; max-width:480px`. This replaces today's "Nothing said yet…" paragraph.
- **Composer**: `border:1px solid #e4ded4; background:#fff; radius:14px; padding:13px 15px; 14.5px`, placeholder **`Message everyone in this album…`** (replacing "Say something about these…"). Under it, `Everyone in this album can read it. Enter sends, Shift + Enter is a new line.` at `12.5px; color:#8a8378`, and a filled `Post` button (`#4e63a8`, `9px 16px`, `radius:10px`) at the right. Keep the existing behaviour: auto-grow to 160px, Enter posts / Shift+Enter newline, `@`-mention completion restricted to this event's contributors, the draft preserved on failure, and the `SignIn`-in-place path when the viewer may read but not post.
- **Messages**: 32px avatar, then `Name · 4 days ago` at `12.5px; color:#8a8378` (name `#14171c/600`), body `14.5px/1.5`. Reactions stay as they are today — pills `padding:4px 9px; radius:999px; border:1px solid #e4ded4` with a `+` opener — but they exist **only on messages, never on photos**. Own-message `···` (edit / delete) and the deleted-message gap are unchanged.

Note: the third block in the prototype file, under "How it reads once people talk", is documentation of the populated state — not a second section to build.

## Interactions & Behavior
- Tab switch is a navigation (`?tab=`), Photos default; the unread pill clears on arriving at Conversation, as today.
- `Add photos` from either the header or the first tile opens the same file input; the upload progress block stays where it is — folded, at the foot of the Photos tab.
- Selection mode: checking a tile's checkbox enters it; the existing footer bar (`Pick the ones you want` / `N selected`, `Download these`, `As JPEG`, `Done`) is unchanged except for colour, and while it is up a tile picks rather than opens.
- Polling for newly ingested photos (`arriving`, 4s, bounded to 30 tries after the last upload) is unchanged.
- Transitions: overlay fades `120ms ease`; tab underline does not animate.
- Focus: `outline:3px solid #4e63a8; outline-offset:2px` on tiles, tabs, and every button.
- Responsive: below 720px the rail becomes the existing top bar; header actions collapse to `Add photos` + `···` (Invite and Download move into the menu); masonry to 2 columns, then 1; tabs scroll horizontally if needed. The phone sheet (`ThreadSheet`) is no longer needed — Conversation is a tab on every width, so delete the sheet path rather than keeping two shapes.

## State Management
- `tab: 'photos' | 'conversation' | 'people'` — from the URL.
- Existing and unchanged: `feed`, `only` (contributor filter — now reachable from People, or drop it in favour of the People tab; the prototype omits the chip row), `picked`, `openPhoto`, `sharing`, `draft`, `lastSeen`/`unread`, `uploads`.
- Removed: `threadOpen` and `pa_thread_folded`.
- Server additions to the event payload: the event's own date for the metadata line (`startsAt`, already present), per-member photo counts, and invite state (invited-by, sent-at, opened) for the People tab.

## Design Tokens
```
--accent: #4e63a8      /* muted logo blue, 5.4:1 on white — was #1a5fd0 */
--accent-soft: #eceffb
--accent-ink: #3f5498
--page-warm: #fbf8f4   /* the album page surface — was #fff */
--line: #e4ded4        /* control borders */
--hairline: #eee7dd    /* the tab rule */
--row-line: #f2ece3    /* People row separators */
--dim: #5b6472
--dim-warm: #8a8378
--fg: #14171c
```
Pastel moments only: lens palette `#ffb3b8 / #9db2f0 / #a5dcc6 / #f3b584` (overlaps `#c79ad9`, `#6fb6c4`, `#b084c5`) for avatars, the mark and the live dot; role pills `#f5ece2` / `#eaf5ef` / `#eef1f4` / `#fbf3e8`; arriving pill `#eaf5ef` on `#3d6a55`.

Radii: 14px photos, tiles and panels · 10px buttons · 8px overlay chips · 999px pills and avatars. Spacing: 2/4/5/6/8/9/10/11/12/14/18/22/26/28/34. Type: system stack; Garet 300 uppercase on the wordmark only. Scale: 25/700 album name · 21/700 and 19/700 tab headings · 15.5/600 person name · 14.5 tabs, buttons, message body, composer · 13.5 metadata and description · 13 creator line and overlay name · 12.5 secondary and handle · 12 uppercase section labels · 11.5 pills.

Shadows: none on photos or rows. Avatar rings `0 0 0 2px #fbf8f4` in the header, `0 0 0 1.5px rgba(255,255,255,.85)` on a photo.

## Assets
- `garet-book.woff2` — bundled; same file as `apps/web/public/fonts/garet-book.woff2`.
- The three-circle mark — reuse `Mark.tsx` verbatim (the prototype inlines identical geometry).
- Photographs and avatars — placeholders; substitute signed URLs from `imageSrc()` / `avatarUrl()`.
- No new icons. `↓` and `···` are text glyphs, as today.

## Files
- `2b-photos-masonry.html` — Photos tab, the default view. **Build this first.**
- `2c-people.html` — People tab.
- `2d-conversation.html` — Conversation tab.
- `Parea Album.dc.html` — the full design document, including the current page recreated as `#1a` for before/after.
- `Parea Rail.dc.html` — the rail with the muted accent.
- `garet-book.woff2`.

Source files this design modifies: `app/event/[id]/page.tsx`, `app/components/EventView.tsx`, `Thread.tsx` (column and sheet → tab), `PhotoTile.tsx`, `Menu.tsx`, `app/globals.css`, `src/members.ts` / `src/contributors.ts` / `src/invites.ts` (People tab data). Update `test/shell.test.ts` and the event-page tests to the new shape rather than working around them.
