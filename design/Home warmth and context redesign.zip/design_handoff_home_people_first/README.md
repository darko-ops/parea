# Handoff: Parea Home — “people first” (option 2d)

## Overview
A redesign of the web client's Home screen (`/albums`, `apps/web/app/albums/page.tsx`). Today Home is a heading that says “Home” above a grid of equal cards whose metadata strip carries `@handle · caption` over a blurred gradient bleed. Three problems were named: Home reads generic rather than like returning to your people; the metadata strip is visually heavy and makes cards resemble marketplace listings; and `--accent: #1a5fd0` at full strength makes the product feel utilitarian.

Option 2d answers all three: the page is titled **Your Parea** under a greeting, the **people you are in albums with** are the first thing on the page (and a filter), albums are **tall full-bleed covers** with contributor faces overlapping the photo's bottom edge and a quiet `N people · Fri 14 Mar` line beneath, and the accent moves to **#4e63a8** — a muted relative of the logo blue `#9db2f0` — with the mark's pastel lens palette doing the small coloured moments.

## About the Design Files
The files in this bundle are **design references created in HTML**. They are prototypes of intended look and behaviour, not production code to copy. The task is to recreate this design inside `apps/web` using its existing environment — Next.js App Router, server components, class-based CSS in `app/globals.css`, and the existing components (`Rail`, `EventCard`, `Faces`, `Lenses`, `MosaicTile`, `CreateCard`). The HTML here uses inline styles purely because the prototyping environment requires it; in the codebase these belong as classes and tokens in `globals.css`, exactly as today.

## Fidelity
**High-fidelity.** Colours, type sizes, radii, gaps and paddings are final and stated below. Photographs and avatars are striped gradient placeholders — the only thing to substitute. Recreate pixel-for-pixel with the codebase's own patterns.

## Screens / Views

### Home — `/albums`
**Purpose:** return to the albums you are in; recognise them by their photographs and by who is in them; reach the one being added to right now; create a new one.

**Layout** — unchanged shell: `.shell` is `display:flex; min-height:100vh`, `Rail` at `width:212px` (sticky, `border-right:1px solid`), `main.main` is `flex:1; min-width:0; padding:28px 30px; display:flex; flex-direction:column`.

Inside `main`, top to bottom:

1. **Greeting** — `font-size:13px; color:#8a8378`. Copy: `Evening, Nadia` (time-of-day greeting + the actor's display name).
2. **Title** — `h1`, `font-size:28px; letter-spacing:-.02em; margin:2px 0 18px`. Copy: `Your Parea`.
3. **People row** — `display:flex; align-items:center; gap:12px; padding:4px 0 20px; overflow:hidden`.
   - Each person: a column, `width:76px; gap:7px`, avatar `56×56; border-radius:50%`, name below at `font-size:12px`.
   - Avatar with a picture: the image, `object-fit:cover`. Without: a flat lens colour from the palette in order (`#ffb3b8`, `#9db2f0`, `#a5dcc6`, `#f3b584`) with the initial centred at `font-size:19px; font-weight:600` in a darkened tone of the same hue (`#7a4f52`, `#3f5296`, `#3f6b57`, `#7d5230`). Never a grey silhouette — same rule as `Faces.tsx`.
   - Selected person: `box-shadow: 0 0 0 2px #fff, 0 0 0 4px #4e63a8`, name goes `font-weight:600; color:#14171c` (others `#5b6472`).
   - Last slot: `Invite` — `56×56` circle, `border:1px dashed #d7d1c6`, `＋` at `font-size:20px; color:#8a8378`.
   - Right end, only while a filter is active: a pill, `font-size:12.5px; color:#5b6472; padding:8px 12px; border:1px solid #e8e4dd; border-radius:999px`, copy `Showing albums with **Priya** · clear` (the name in `#3f5498; font-weight:700`, `clear` is the reset).
4. **Album grid** — `border-top:1px solid #f0ece5; padding-top:22px; display:grid; gap:20px; grid-template-columns:repeat(auto-fill, minmax(290px,1fr))` (the prototype pins 4 columns at 1456px; keep today's `auto-fill/minmax` behaviour).

**Album card** (an `<a>` to `/event/<id>` or `/e/<token>`, `display:flex; flex-direction:column; text-decoration:none; color:inherit`; no border, no background, no card box — the photograph is the card):
- **Cover** — `height:320px; border-radius:16px; overflow:hidden`, single full-bleed image, `object-fit:cover`. This is `leadImage()` in `src/cards.ts`: the cover if set, otherwise the newest photograph. The 3-tile mosaic is dropped on this screen.
- **Live badge** (only on an album added to inside the last hour) — absolutely positioned `left:12px; top:12px`, `padding:5px 10px; border-radius:999px; background:rgba(255,255,255,.93); font-size:11.5px; font-weight:600; color:#3d6a55`, preceded by a `6×6` dot in `#a5dcc6`. Copy: `Being added to now`.
- **Faces** — a row overlapping the photo's bottom edge: `margin:-16px 0 0 12px`, circles `32×32`, `margin-left:-10px` after the first, each `box-shadow: 0 0 0 2.5px #fff`. Up to 3 real faces (host first, as `Faces.tsx` orders them) then an overflow chip `+5` — `background:#f0ece5; font-size:11px; font-weight:600; color:#5b6472`. Fewer than 4 contributors: just those circles, no chip.
- **Title** — `padding:12px 2px 0`, `font-size:17px; font-weight:700; letter-spacing:-.015em`, one line, ellipsised.
- **Meta** — `font-size:13px; color:#5b6472; margin-top:4px`. Copy: `8 people · Fri 14 Mar` — the member count (`memberCount`, `person`/`people` pluralised) and the event's own date, formatted `EEE d MMM`. On the live album substitute the recency: `8 people · added to 20m ago` using `ago()` from `@parea/cards`. No handle, no caption, no photo count on screen (the count stays in the card's `aria-label`, as today).
- **`aria-label`** stays `"{name}, {photoCount} photos"`.

**Create cell** — last cell, same height as a cover (`height:320px`), `border-radius:16px; border:1px dashed #d7d1c6; display:flex; flex-direction:column; justify-content:center; gap:10px; padding:20px`. Contents: two lenses (`20×20`, `#a5dcc6` then `#c79ad9` at `margin-left:-7px` — `CREATE_LENSES`), `Create Album` at `17px/600`, then `Name it, say when it was, send the link. Nothing to sign up for at the other end to look.` at `13.5px; color:#5b6472; line-height:1.5`.

**Empty album card** (no photographs — keep the existing separate card from `EventCard.tsx`) — unchanged in structure; only the button colour changes, `background:#4e63a8`.

### Rail — `apps/web/app/components/Rail.tsx`
Unchanged in structure (Home / Activity / Search / Profile, Create Album and Settings in the foot). Two colour changes only:
- active row: `background:#eceffb; color:#3f5498` (was `--accent-soft #e8eefb` / `--accent #1a5fd0`)
- `Create Album` button and the Activity badge: `background:#4e63a8`
- rail border and dividers move to the warmer `#e8e4dd`

## Interactions & Behavior
- **Person tap** filters the grid to albums that person is in: ring appears on the avatar, the `Showing albums with X · clear` pill appears, cards outside the filter are removed. Client-side over the list the server already sent — same reasoning as `SearchEvents.tsx`; no `?q=` navigation, nothing refetched.
- **`clear`** removes the filter and the pill.
- **Card hover:** cover scales `1.02` over `160ms ease` inside its `overflow:hidden` corner, title goes `#000`. No border or shadow change — there is no border to change.
- **Focus:** `outline:3px solid #4e63a8; outline-offset:2px` on the card `<a>` and on each person button.
- **Search** stays the collapsing field from `SearchEvents.tsx` (icon → 220px field, `140ms ease`), moved to the right of the title row; its focus ring becomes `border-color:#4e63a8; box-shadow:0 0 0 3px #eceffb`.
- **Live badge dot** uses the existing `@keyframes pulse`; suppressed under `prefers-reduced-motion`.
- **Responsive:** below 720px the rail becomes the top bar (existing rule); the people row scrolls horizontally with `overflow-x:auto` and momentum; the grid falls to two columns at ~700px and one below ~460px, cover height `320px → 260px → 300px`.
- **Loading / failure:** covers and avatars are presigned and expire — keep `useImageFailure`. A cover that fails leaves the tile's own flat background (`#f0ece5`) rather than a broken glyph; an avatar that fails falls back to its lens colour and initial.

## State Management
- `selectedPersonId: string | null` — the people-row filter. Client state in the component that wraps the grid; the cards stay server-rendered and are filtered by the `data-event` wrapper id, exactly as `SearchEvents` does today.
- `query: string` — existing search state, unchanged.
- Server data per card, from `toCards()` in `src/cards.ts`: add `eventDate` (the event's own window start, ISO) and `contributors: {id, name, avatarUrl|null}[]` capped at 4 + a total; `caption` and `creatorHandle` are no longer rendered on this screen. The people row needs a new query: people sharing ≥1 album with the actor, most recently active first (`src/people.ts` / `src/contributors.ts`).

## Design Tokens
Colours (changes marked ▲):
- ▲ `--accent: #4e63a8` (was `#1a5fd0`) — 5.4:1 on white, passes AA for the 15px button label
- ▲ `--accent-soft: #eceffb` (was `#e8eefb`)
- ▲ `--accent-ink: #3f5498` — accent text on white/soft fills
- ▲ `--line: #e8e4dd`, `--hairline: #f0ece5`, `--line-dashed: #d7d1c6` (warmer than `#e3e6ea` / `#eef1f4` / `#d3d8de`)
- ▲ `--dim-warm: #8a8378` — the greeting, dates, section counts
- `--bg: #fff`, `--card: #fff`, `--fg: #14171c`, `--dim: #5b6472` — unchanged
- Lens palette, unchanged: `#ffb3b8`, `#9db2f0`, `#a5dcc6`, `#f3b584`; overlaps `#c79ad9`, `#6fb6c4`, `#b084c5`; create pair `#a5dcc6` + `#c79ad9`
- Live badge: fill `rgba(255,255,255,.93)`, text `#3d6a55`, dot `#a5dcc6`
- Removed: `--scrim` / `--scrim-deep` and the `.card-bleed` blur are no longer used on Home (still used by the event hero)

Spacing: 2 / 4 / 6 / 7 / 10 / 12 / 18 / 20 / 22 / 28 / 30px. Grid gap 20px, page padding `28px 30px`.

Type: system stack (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`) throughout; Garet 300 uppercase `letter-spacing:.04em` with `-webkit-text-stroke:0.045em` for the wordmark only. Scale: 28/700 h1 · 17/700 card title · 15 rail row · 13 meta · 13 greeting · 12 person name · 12.5 filter pill · 11.5 live badge · 11 overflow chip.

Radii: 16px cover and create cell · 999px pills and avatars · 10px buttons · 8px rail rows.
Shadows: none on cards; `0 0 0 2.5px #fff` rings on faces; `0 0 0 2px #fff, 0 0 0 4px #4e63a8` on the selected person.

## Assets
- `garet-book.woff2` — bundled here, same file as `apps/web/public/fonts/garet-book.woff2`.
- Mark and rail glyphs — reuse `Mark.tsx` and `RailIcon.tsx` verbatim; the prototype inlines identical SVG.
- Photographs and avatars — striped gradient placeholders in the prototype. Substitute real signed URLs (`leadImage()`, `avatarUrl()`). No new icons are introduced.

## Files
- `2d-home-people-first.html` — the design, standalone, opens in a browser. **This is the reference to build from.**
- `Parea Home.dc.html` — the full design document: today's Home recreated (`#1a`) and all four proposals (`#2a`–`#2d`) for context on what was rejected and why.
- `Parea Rail.dc.html` — the rail with the muted accent applied.
- `garet-book.woff2` — wordmark font.

Source files this design modifies: `app/albums/page.tsx`, `app/components/EventCard.tsx`, `app/components/Faces.tsx`, `app/components/Rail.tsx`, `app/components/SearchEvents.tsx`, `app/globals.css`, `src/cards.ts` (plus a new people-row query).
