# Handoff: Event message thread (Parea)

## Overview
Adds a per-event message thread to the Parea event page so contributors can talk
about the photos in the place the photos are, instead of in the group chat the
event link was pasted into. Three accepted treatments:

- **1a** — thread as a right-hand column beside the photo grid (desktop, primary)
- **1c** — the same thread on mobile: collapses to a `Thread` button in the event
  head, opens as a bottom sheet
- **1d** — photo-anchored comments inside the existing `PhotoLightbox`, which also
  appear in the event thread

Scope of a thread is **the event** (not groups, not a separate inbox).
Posting is limited to people who may add photos (signed-in contributors);
everyone who can view the event can read.

## About the Design Files
`Event thread.dc.html` in this bundle is a **design reference created in HTML** —
a prototype showing intended look and layout, not production code to copy. The
task is to recreate these designs inside `apps/web` (Next.js App Router, React
client components, plain CSS in `app/globals.css`) using its existing patterns:
class-based CSS in `globals.css` with the existing custom properties, components
in `app/components/*.tsx`, `'use client'` only on the leaves that need state.

The prototype uses **inline styles** purely because of the tool it was authored
in. Do **not** port inline styles — add classes to `globals.css` alongside the
existing `.event-*`, `.chip`, `.uploads` blocks, in the same commented style.

`reference/globals.css` is the current stylesheet, copied at the time of handoff,
so the token values below can be checked against source.

## Fidelity
**High-fidelity.** Every value below is taken from
`apps/web/app/globals.css` or the components listed under Files. Colours,
type sizes, radii and spacing are final. The recreation should be pixel-accurate.

Anything *new* (the thread column, the sheet, the photo comments) reuses existing
tokens only — no new colours were invented.

## Screens / Views

### 1a — Event page with thread column (desktop)

Existing page, unchanged, plus one new `<aside>`.

**Layout**
- `.shell` — `display:flex; min-height:100vh`
- `.rail` — 212px fixed, `padding:22px 16px`, `border-right:1px solid var(--line)`
- `.event` — `flex:1; min-width:0`
- `.event-head` — sticky, `top:0`, `z-index:2`, `display:flex; align-items:center;
  gap:16px; padding:14px 24px`, `border-bottom:1px solid var(--line)`,
  `background:rgba(255,255,255,.92); backdrop-filter:blur(8px)`
- **New:** below the head, the body becomes a two-column flex row:
  `.event-body` (`flex:1; min-width:0`) + `.thread` (`width:360px; flex:none;
  border-left:1px solid var(--line)`). `.event-body` keeps its existing
  `padding:20px 24px 28px; display:flex; flex-direction:column; gap:18px`.
- The thread column is its own scroll container and sticks under the head:
  `position:sticky; top:<head height>; height:calc(100vh - <head height>);
  display:flex; flex-direction:column`.

**Thread column components**

| Part | Spec |
| --- | --- |
| Header | `padding:14px 18px`, `border-bottom:1px solid var(--line)`. Title `15px/600`, letter-spacing `-.01em`. Count right-aligned, `13px`, `var(--dim)`, `font-variant-numeric:tabular-nums`. |
| List | `flex:1; overflow-y:auto; padding:16px 18px; display:flex; flex-direction:column; gap:16px` |
| Avatar | 28px circle, `background:var(--accent-soft)`, `color:var(--accent)`, `12px/600`, single upper-cased initial — same construction as `.chip-face` (20px) and `.you-face` (64px) |
| Message row | `display:flex; gap:10px`. Meta line `13px`: name `600`, time `12.5px var(--dim)`. Body `14.5px/1.5`, margin 0. |
| @mention | inline `span`, `background:var(--accent-soft); color:var(--accent); border-radius:4px; padding:0 3px; font-weight:600` |
| Attached photos | `display:grid; grid-template-columns:repeat(2,1fr); gap:6px`, tiles `aspect-ratio:1; border-radius:8px; border:1px solid var(--line)` — same 8px radius as `.grid img` |
| Reaction pill | `padding:3px 9px; border-radius:999px; border:1px solid var(--line); font-size:13px; tabular-nums`. Reacted state = `.chip[aria-pressed=true]`: `border:1.5px solid var(--accent); background:var(--accent-soft); color:var(--accent); font-weight:600` |
| Add-reaction | 26×24, `border-radius:999px; border:1px dashed var(--line-dashed); color:var(--dim)` — dashed already means "nothing here yet" everywhere in this product |
| System event | centred row: two `1px` `var(--hairline)` rules with `12.5px var(--dim)` text between; optional three 20px `border-radius:4px` thumbnails |
| Own-message menu | `···` at the end of the meta line, `13px var(--dim)`, `letter-spacing:.08em`; opens the existing `.menu-body` popover (Edit / Delete). "edited" appended to the timestamp in `var(--dim)`. |
| Composer | `border-top:1px solid var(--line); padding:12px 14px 14px; display:flex; flex-direction:column; gap:9px`. Textarea styled as the global input: `border:1px solid var(--line); border-radius:12px; padding:11px 13px; font-size:15px`, autogrow, focus ring `box-shadow:0 0 0 3px var(--accent-soft); border-color:var(--accent)` (`:focus-visible` only, as elsewhere). Row under it: two 34px `border-radius:8px` icon buttons (attach photo from event / mention), a `12px var(--dim)` note, and `Post` (`padding:8px 15px; font-size:14px; border-radius:10px; background:var(--accent)`). |

**Copy used** — "Say something to the seven of you…" (placeholder),
"Only people who can add photos can post.", "Maya added 24 photos · 23:52",
"Sofia joined from a link · 10:31", "Theo made this event · Saturday 19:40".

### 1c — Mobile

- Below 720px the rail is already a horizontal bar (`@media (max-width:720px)` in
  `globals.css`) — unchanged.
- The thread column is **not** rendered inline. Instead the head gains a
  `Thread` control shaped like `.chip` (`padding:8px 13px; border-radius:999px;
  border:1px solid var(--line); font-size:14px; font-weight:600`) with the
  existing `.badge` (20px pill, `var(--accent)`, `12px/700`) carrying the unread
  count.
- Tapping it opens a bottom sheet: `position:fixed; left:0; right:0; bottom:0;
  height:min(82vh,620px); background:var(--card); border-radius:20px 20px 0 0;
  box-shadow:0 -8px 24px rgba(20,23,28,.12)`, over a `rgba(20,23,28,.28)` scrim.
  Grab handle 36×4, `border-radius:999px`, `background:var(--line-dashed)`.
- Inside, message body type goes 14.5px → **15px**, composer controls to 40/44px
  hit targets, bottom padding 20px for the home indicator.
- Dismiss: scrim tap, drag down, Escape. Trap focus while open; restore focus to
  the `Thread` button on close.

### 1d — Photo-anchored comments (lightbox)

`PhotoLightbox.tsx`, unchanged except for one inserted block.

Existing structure kept exactly: `.lightbox` (fixed, `rgba(0,0,0,.82)`) >
`.lightbox-inner` (`max-width:720px; border-radius:14px; padding:16px; display:grid;
gap:14px`) > image (`max-height:60vh`), then `.lightbox-actions` (`display:grid;
gap:10px`) with the real action set — for someone else's photo:
"That's me — take it down", "Report", "Block this person" (all `.secondary`;
Block swaps to a filled "Block — hide all their photos" on confirm) — then "Close"
(`.secondary`). For your own photo the actions are "Remove my photo" (filled) and
the muted line "Yours. Nobody has to approve this."

**Inserted between the image and `.lightbox-actions`:** a comment block with the
same message rows and reaction pills as 1a, then a composer row —
placeholder "Comment on this photo…", `Post` button — and the muted 12.5px line
"Photo comments also appear in the event thread."

Photo comments and event messages are the same records; a photo comment carries a
`photoId` and renders in the thread with its thumbnail attached.

## Interactions & Behavior
- **Post** — optimistic append with a pending state; on failure the row stays with
  a retry, matching how the upload queue reports per-item failure rather than
  discarding work.
- **Poll** — the event page already polls `/api/events/:id/photos` every 4s while
  `uploads.running || feed.arriving > 0` (bounded by `INGEST_POLLS = 30`). Fold new
  messages into the same poll rather than adding a second timer; when nothing is
  in flight, poll the thread at a slower interval and stop after the same bound.
- **Unread** — count of messages after the viewer's last-seen timestamp for this
  event. On desktop the column is visible, so mark seen on scroll-to-bottom; on
  mobile mark seen when the sheet opens. Clearing on arrival is the same rule the
  rail's Invites badge already follows.
- **Reactions** — toggle, optimistic, `aria-pressed` on the pill.
- **Edit** — inline; the textarea replaces the body in place. "edited" appended
  permanently. **Delete** — own message only, tombstoned as "Message deleted" in
  `var(--dim)` so replies above and below keep their order.
- **@mention** — typing `@` opens a list of the event's contributors (the same
  `people[]` the chips are built from). Never suggests someone outside the event.
- **Read-only** — a viewer who cannot add photos sees the list and, in place of
  the composer, the muted line "Only people who can add photos can post." A signed-
  out viewer gets the existing `SignIn` component with a `why` prop, exactly as
  the upload path does — never a redirect away from the page.
- **Reduced motion** — no new animation. The only animated things on the page stay
  `.hero-dot` / `.arriving-dot` / `.bar-fill`, all already covered.

## State Management
Client state in a `Thread` component (`'use client'`):
- `messages: Message[]` — seeded server-side from the event page, like `photos`
- `draft: string`, `posting: boolean`, `error: string | null`
- `editingId: string | null`
- `openMenuId: string | null`
- `sheetOpen: boolean` (mobile only)
- `lastSeenAt: string` — persisted per event

Server: extend the event page's initial payload with `messages` so the thread
renders in the first HTML response, the same argument the grid already makes.

Suggested endpoints, following existing shapes:
`GET/POST /api/events/:id/messages`, `PATCH/DELETE /api/messages/:mid`,
`POST /api/messages/:mid/reactions`.

Access: whatever `authorize()` returns for `view` gates reading; posting gates on
the same decision the upload path uses. Denials that would confirm an event
exists must answer 404, per the existing access rule.

## Design Tokens
From `:root` in `globals.css` — no new values introduced.

| Token | Value | Used for |
| --- | --- | --- |
| `--bg` / `--card` | `#fff` | page, thread surface |
| `--fg` | `#14171c` | message body |
| `--dim` | `#5b6472` | timestamps, system events, notes |
| `--line` | `#e3e6ea` | column edge, composer border, pills |
| `--hairline` | `#eef1f4` | rules inside the system-event row |
| `--line-dashed` | `#d3d8de` | add-reaction outline, sheet handle |
| `--track` | `#f4f6f8` | compact-density row tint |
| `--accent` | `#1a5fd0` | Post, mentions, active reaction, badge |
| `--accent-soft` | `#e8eefb` | avatars, mention chip, reacted pill, focus ring |

**Type** — body `16px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
sans-serif`. Message body 14.5px (15px in the mobile sheet), name 13px/600,
timestamp 12.5px, column title 15px/600, composer 15px.
Garet 300 is wordmark-only and unchanged.

**Radii** — 4px mention · 6–8px thumbnails · 8px icon buttons · 10px buttons ·
12px composer · 14px lightbox · 20px sheet top · 999px pills.

**Spacing** — 16px between messages, 10px avatar↔body, 6px reaction gap,
16/18px column padding, 14/18px header padding.

**Shadows** — sheet `0 -8px 24px rgba(20,23,28,.12)`; popovers reuse the existing
`.menu-body` shadow.

## Assets
No new assets. The mark is the existing inline SVG in `Mark.tsx` (geometry is
checked against the app icon by `brand.test.ts` — do not redraw it). Photo tiles
in the prototype are striped placeholders standing in for real thumbnails.
Reaction glyphs in the prototype (`♥`, `✦`) are placeholders — pick the real
emoji set during implementation.

## Files
In this bundle:
- `Event thread.dc.html` — the prototype, options 1a / 1b / 1c / 1d
- `reference/globals.css` — the stylesheet the values above come from

In `darko-ops/parea` @ `claude/photo-sharing-concept-ch3apn`, the files to change
or read:
- `apps/web/app/event/[id]/page.tsx` — server payload, add `messages`
- `apps/web/app/components/EventView.tsx` — the two-column body, the head control
- `apps/web/app/components/PhotoLightbox.tsx` — 1d
- `apps/web/app/components/SignIn.tsx` — read-only / signed-out composer
- `apps/web/app/components/Rail.tsx`, `Shell.tsx`, `Mark.tsx` — page chrome, unchanged
- `apps/web/app/globals.css` — new `.thread-*` classes
