# Handoff: Parea — home density, brand-forward cards, live event view

## Overview

Three design changes to the existing Parea web client, plus a pixel-faithful recreation of the current UI they build on. They target the two screens that carry the product: **Home** (`/events`) and the **event view** (`/event/[id]`).

- **1a — Home, re-densified.** A hero slot for the event still being added to, then compact rows. Nine events on a screen instead of four; "Add yours" reachable without opening anything.
- **1b — Brand-forward event cards.** The mark's three lenses become the visual language for "who was there"; the photo count becomes a debossed Garet numeral in the card's blurred strip; the scrim lets more of the photos' own colour through.
- **1c — The event while it is happening.** A sticky header that keeps the count and download in reach, per-file upload rows in a collapsible block at the foot of the page, a contributor filter, and time-grouped grid sections.

## About the design files

The files in this bundle are **design references written as HTML** — prototypes of intended look and behaviour, not production code to copy. The task is to **recreate them inside `apps/web`**, which is Next.js App Router with a single global stylesheet (`apps/web/app/globals.css`) and server components where possible.

Follow the codebase's existing conventions rather than the prototypes' markup:

- Styling belongs in `globals.css` as semantic classes (`.card`, `.mosaic`, `.rail-row`…), **not** inline styles. The prototypes use inline styles purely because of the tool they were authored in.
- Keep components server-rendered unless they need state. The existing split is deliberate: `EventCard` is a server component and only its leaf `MosaicTile` is `'use client'` (image-failure detection). Preserve that.
- Reuse what exists: `Shell`, `Rail`, `Mark`, `EventCard`, `MosaicTile`, `PhotoTile`, `SiteFooter`, `Avatar`, and `metaFor`/`ago` from `@parea/cards`. Anything shared with native (card meta strings, tile layout by photo count) must stay shared — the mosaic `layout()` function is duplicated in `apps/web/app/components/EventCard.tsx` and `apps/mobile/src/Events.tsx` on purpose and the two must keep drawing the same shape.
- Photo bytes never pass through Next.js. All image URLs stay signed URLs from `@parea/urls`; nothing here changes that.

## Fidelity

**High-fidelity.** Colours, type, spacing and radii are exact and mostly lifted from `globals.css` as it stands. Recreate pixel-perfectly. The one deliberately illustrative part is content: names, counts, contributor letters and filenames are sample data.

Photographs in the prototypes are striped placeholder blocks (`repeating-linear-gradient(135deg, <tintA> 0 8px, <tintB> 8px 16px)`). Every one of them stands for a real `<img>`/`<picture>` from a signed URL. Do not ship the stripes.

---

## Screens / Views

### 0. Recreation baseline (`Parea — Current UI.dc.html`)

Not a change request. It is the current product drawn from source so the deltas below are legible: web Home, Create step two with the share aside, event view, Find, You, and three native screens (Events tab, event screen, post-create share sheet). Use it to check that a change does not disturb what surrounds it.

---

### 1a — Home, re-densified

**Route:** `/events` (`apps/web/app/events/page.tsx`)
**Purpose:** Land somewhere that says what is happening, and let someone contribute from the list.

**Layout**

- Unchanged shell: `.shell` flex row → `.rail` 212px (sticky, `height: 100dvh`, `border-right: 1px solid var(--line)`) + `.main` (`flex: 1; padding: 28px 30px`).
- `.main-head`: `display:flex; align-items:baseline; justify-content:space-between; gap:16px; margin-bottom:18px`. `h1` "Home" at 28px/`letter-spacing:-.02em`.
- **Right of the head**: a segmented control replacing today's "Most recently added to first" caption. Track `padding:3px; background:#f4f6f8; border-radius:999px; display:flex; gap:4px`. Segments `padding:6px 13px; border-radius:999px; font-size:13px`. Active: `background:#fff; color:var(--fg); font-weight:600; box-shadow:0 1px 2px rgba(20,23,28,.08)`. Inactive: `color:var(--dim)`. Labels: **Recent**, **By place**.
- **Hero card** (one, only when an event qualifies — see Interactions): full width, `border:1px solid var(--line); border-radius:16px; overflow:hidden; margin-bottom:20px`.
  - Mosaic: same `grid-template-columns` weights as today's `layout()` (`2fr 1fr 1fr` at 4+ photos, with the middle column split `1fr 1fr`), `gap:2px`, but **height 214px** rather than 150px.
  - Body: identical technique to today's `.card-body` — `position:relative; overflow:hidden`, a `.card-bleed` at `inset:-24px` with `display:flex; transform:scaleY(-1); filter:blur(18px) saturate(1.15)` carrying one band per mosaic column at that column's `flex` weight, then `.card-scrim` `linear-gradient(180deg, rgba(255,255,255,.62), rgba(255,255,255,.9))`. (Note the bottom stop is `.9`, slightly denser than the current `.88`, because the text row is taller.)
  - Text row: `position:relative; display:flex; align-items:center; gap:18px; padding:16px 18px 17px`.
    - Live label: 7px dot `background:var(--accent); border-radius:50%`, pulsing (see Interactions), then `STILL COMING IN` at `font-size:12.5px; font-weight:600; color:var(--accent); letter-spacing:.02em`.
    - Name: 26px/700/`letter-spacing:-.02em`, `margin-top:3px`.
    - Meta: 14px `color:var(--dim)` — `"6 people · added to 20m ago · 40 arriving from Maya"`. First two segments come from `metaFor()`; the third is new (see State).
    - Contributor faces: 30px circles, `border-radius:50%`, `border:2px solid #fff`, overlapped `margin-left:-14px`, `font-size:13px; font-weight:600`, centred. First uses the existing avatar pair `background:#e8eefb; color:#1a5fd0`; the others are tinted stand-ins in the same lightness family (`#f3e2e3`/`#8d5f63`, `#e2ece6`/`#4f7a68`). Overflow as `+3` at 13px `var(--dim)`, `margin-left:4px`. These are `Avatar` with a smaller `className` — add a `.face-sm` class rather than a second component.
    - Primary action: `padding:11px 17px; border-radius:10px; background:var(--accent); color:#fff; font-size:15px; font-weight:600` — label **Add yours**. It is a `<label htmlFor>` over a hidden file input, exactly as `EventView`'s add-photos control is, so it works without script.
    - Count: 22px/600 `color:var(--dim)`, `font-variant-numeric:tabular-nums`.
- **Compact rows**: one container `border:1px solid var(--line); border-radius:14px; overflow:hidden`, rows separated by `border-bottom:1px solid #eef1f4` (lighter than `--line`; it is an interior rule, not an edge). Row: `display:flex; align-items:center; gap:14px; padding:10px 14px`.
  - Thumb strip: fixed `112×58`, `border-radius:8px; overflow:hidden; display:flex; gap:2px`, columns at the same weights the mosaic would use (`2fr 1fr 1fr`, or `1fr 1fr` at two photos). Stripe width in the placeholders drops to 6px only because the box is smaller — irrelevant once real images land.
  - Name 16.5px/600/`-.01em`; meta 13px `var(--dim)`; count 17px/600 `var(--dim)` tabular.
  - **Empty event row**: thumb slot becomes `border:1px dashed var(--line-dashed)` with the words `no photos` at 11px `var(--dim)`; meta reads `"2 people · nobody has added anything yet"`; the count is replaced by a secondary **Add yours** at `padding:7px 12px; border-radius:8px; border:1px solid var(--line); font-size:13px; font-weight:600`.
  - **Last row is the create affordance**, replacing today's `.card-new` cell: `padding:12px 14px; color:var(--dim); font-size:14px`, a `＋` centred in the 112px thumb column, then "Create Event — name it, say when it was, send the link." It stays an `<a href="/">`.
- `SiteFooter` unchanged.

**What is removed:** the `.cards` grid (`repeat(auto-fill, minmax(290px,1fr))`) on this route and the "Most recently added to first" caption. `.cards` is still used by `/invites` and the You page, so keep the class.

---

### 1b — Brand-forward event cards

**Where:** `EventCard` — affects `/events`, `/invites`, and the You page at once.
**Purpose:** Make a card recognisable as Parea's, and make "who was there" a picture rather than a sentence.

**Layout** (a 300px-min grid; shown at 700px wide in the prototype)

- Card: `border:1px solid var(--line); border-radius:20px` (up from 14px); `overflow:hidden`.
- Mosaic: **height 168px**, `gap:3px` (up from 2px), simplified weights — `2fr 1fr` with the right column split at 4 photos, `1fr 1fr` at two.
- Body scrim is **lighter**: `linear-gradient(180deg, rgba(255,255,255,.34), rgba(255,255,255,.78))` against today's `.62 → .88`; bleed `inset:-26px; filter:blur(20px) saturate(1.35)`. More of the album's colour survives. Verify contrast on a dark album: name is `#14171c` on a ≥`.34` white wash — if a real photo set fails WCAG AA here, raise the top stop rather than darken the text.
- Text row: `padding:14px 16px 16px; display:flex; align-items:flex-end; gap:14px`.
  - Name 20px/700/`-.015em`, ellipsised.
  - **Contributor line, two treatments** — pick one, do not ship both:
    1. The `Mark` at `size={22}` beside "6 people put these here" (13.5px, `color:var(--fg)`, `font-weight:500`). The mark already means "three people's photos, overlapping".
    2. A row of 14px lens circles, one per contributor, overlapped `margin-left:-5px`, in mark order `#ffb3b8, #9db2f0, #a5dcc6, #f3b584`, followed by the place at 13.5px. Cap at four circles.
  - **Count, debossed**: Garet 24px/300, `letter-spacing:.02em`, `font-variant-numeric:tabular-nums`, `color:rgba(20,23,28,.22)`, `text-shadow:0 1px 0 rgba(255,255,255,.8), 0 -1px 1px rgba(20,23,28,.14)`. No "PHOTOS" caption, no `-webkit-text-stroke` (the stroke belongs to the wordmark only). It reads as pressed into the blurred strip — present, subordinate to the name.
    - Accessibility: the number's contrast is intentionally below AA, so it must not be the only carrier of the count. The card's `aria-label` already says `"<name>, N photos"` — keep it.
    - This extends Garet beyond the wordmark, which `globals.css` currently forbids in prose. Numerals are the exception being proposed; if you reject it, use `-apple-system` at 600 and the same colour treatment.
- **Empty event card** (no photos, replacing `.card-bare`): `min-height:238px; padding:18px; display:flex; flex-direction:column; justify-content:space-between`. Name, then "You and one other. Nothing in it yet.", then a centred lens cluster — two 52px circles at `opacity:.5` (`#ffb3b8`, `#9db2f0`) overlapped `-18px`, and a third 52px `border:1px dashed var(--line-dashed)` circle holding a `＋`, the empty slot being *you*. Full-width primary **Add yours first** (`padding:12px 0; border-radius:12px`).
- **Create cell**: `border:1px dashed var(--line-dashed); border-radius:20px; min-height:238px`, a small two-lens mark (18px `#a5dcc6` + `#c79ad9` overlapped `-6px`), then today's copy unchanged.

---

### 1c — The event while it is happening

**Route:** `/event/[id]` (`EventView.tsx`). Column width 900px, matching `.wrap`.
**Purpose:** Make an event that is actively receiving photos legible, and make a 200-photo grid answerable to "whose is this?".

**Layout**

- **Sticky header** replacing today's static `<header>`: `position:sticky; top:0; background:rgba(255,255,255,.92); backdrop-filter:blur(8px); border-bottom:1px solid var(--line); padding:14px 24px; display:flex; align-items:center; gap:16px`.
  - Name 20px/700/`-.015em`; sub-line 13px `var(--dim)` — `"214 photos from 6 people · Manage"` (`Manage` only when `canAdminister`; group link keeps its place when `groupId`).
  - **Arriving pill**: `padding:6px 12px; border-radius:999px; background:var(--accent-soft); color:var(--accent); font-size:13px; font-weight:600`, with a 7px pulsing accent dot. Text `"12 arriving"`. Rendered only when photos are uploaded-but-not-`ready`.
  - **Download all**: secondary, `padding:10px 15px; border-radius:10px; border:1px solid var(--line); font-size:14px; font-weight:600`. It opens the existing two-option choice (originals / JPEG) rather than picking for someone — §7.7 still applies, so this is a menu or a small popover containing today's two buttons and their explanatory paragraph, not a silent default.
  - **Add photos**: primary, `padding:10px 14px; border-radius:10px`. Same hidden-input-plus-label mechanism as today.
- **Body**: `padding:20px 24px 28px; display:flex; flex-direction:column; gap:18px`.
- **Contributor filter**: a wrapping row of chips, `gap:8px`. Selected: `padding:8px 13px; border-radius:999px; border:1.5px solid var(--accent); background:var(--accent-soft); color:var(--accent); font-size:14px; font-weight:600` — identical to the existing `.pill[aria-pressed='true']`. Unselected: `border:1px solid var(--line)`. Person chips carry a 20px letter avatar (`font-size:11px; font-weight:600`) and `"Maya · 61"`. First chip `"Everyone · 214"`, last `"Mine · 22"` at `color:var(--dim)`.
  - Only counts of photos the viewer can see. A blocked person's uploads are already invisible; they must not reappear as a chip or in a total.
  - Names come from `displayName`, falling back to `@handle`, falling back to "Someone" — the same `name()` rule as `FriendsView`.
- **Grid sections**: each has a head (`display:flex; align-items:baseline; gap:8px; margin:0 0 8px`) with a 13px/`letter-spacing:.02em` `var(--dim)` label and a 13px `var(--dim)` caption, then the grid at `repeat(auto-fill, minmax(140px,1fr)); gap:8px` (today's grid is `minmax(150px,1fr)`).
  - `JUST ADDED` / "Maya, a minute ago" — tiles carry `box-shadow:0 0 0 2px var(--accent)`.
  - `EARLIER` / "Saturday night, 20:14 onwards" — plain tiles. Caption comes from the event window (`startsAt`) when set, else from the first `takenAt`.
  - Failed tiles keep today's `.tile-empty` treatment: `border:1px dashed var(--line-dashed)`, "Not available", still a button (guideline 1.2 — the lightbox's report/takedown actions must stay reachable).
- **Upload block — at the foot of the page, collapsible.** `<details>` with `border:1px solid var(--line); border-radius:14px`.
  - `<summary>`: `list-style:none; cursor:pointer; padding:13px 16px; display:flex; align-items:center; gap:14px`. A `▾` marker at 12px `var(--dim)` (rotate it on `[open]`; also `summary::-webkit-details-marker{display:none}`). Then title `"Adding 40 photos · 12 done"` at 15px/700 with `"Keep this tab open. A reload carries on from here."` at 13px `var(--dim)` under it; a 180×6px overall bar; and `"28 to go"` at 13px `var(--dim)` tabular.
  - Overall bar: track `background:#eef1f4; border-radius:999px`, fill `width:<done/total>%`, `background:repeating-linear-gradient(90deg, var(--accent) 0 14px, #3d7ade 14px 22px)`, animated (see Interactions).
  - Panel: `border-top:1px solid #eef1f4; padding:14px 16px 16px; display:grid; gap:8px`. One row per file: 36px thumb (`border-radius:8px`), filename in `13px ui-monospace, Menlo, monospace`, a 3px per-file progress bar, and a right-hand `%` at 12.5px `var(--dim)`.
  - **Stale row** (a `File` handle that came back dead): thumb becomes `border:1px dashed var(--line-dashed)` with `!`; the sentence is today's — "Could not be read after the reload — your browser only lends a file to the tab that picked it." — and the action is **Pick again** (`padding:7px 11px; border-radius:8px; border:1px solid var(--line); font-size:13px; font-weight:600`), which opens the picker. Not "Retry": nothing retries bytes the browser no longer has.
  - Position and default state: bottom of the column, `open` while a batch is running, collapsed once it finishes with nothing needing attention. Do not collapse it while any row is stale or failed.

---

## Interactions & behaviour

- **Pulsing dot** (1a hero label, 1c arriving pill): `@keyframes` opacity `1 → .35 → 1`, 1.6–1.8s `ease-in-out`, infinite. Wrap in `@media (prefers-reduced-motion: reduce)` and drop to static full opacity.
- **Moving upload bar** (1c): a repeating 90° gradient with `background-position` animated `0 → 44px` over 1.1s `linear`, infinite. It signals liveness; the *width* signals progress. Under reduced-motion, keep the width and stop the slide.
- **Per-file progress**: driven by the existing `useUploads` queue — concurrency 3, per-file progress, persisted across reload. No new mechanism; this is only a view of state it already holds.
- **Grid refresh**: `EventView` already polls `/api/events/<id>/photos` every 4s while uploading. `JUST ADDED` is what that poll now produces — photos that turned `ready` since mount, not "recently uploaded".
- **Contributor filter**: client-side over the loaded feed if the whole feed is in memory; otherwise a query param. It must never widen visibility — filtering is subtractive only.
- **Segmented Recent / By place** (1a): two links, not two buttons — `/events` and `/events?by=place` — so the state survives a reload and can be sent. Mark with `aria-current="page"`, matching `.tabs` and `.rail-row`.
- **Hero eligibility**: an event with photos arriving or added to within the last hour. If nothing qualifies, either promote the most recently added-to event (today's ordering) or render rows only — **this is an open decision, ask before choosing**.
- **Hover**: cards keep today's `border-color: var(--line-dashed); box-shadow: 0 1px 3px rgba(0,0,0,.06)`. New rows get the same border treatment on hover, no lift.
- **Focus**: every new interactive element takes the existing `:focus-visible` ring — `3px solid var(--accent); outline-offset:2px` for tiles and cards, `border-color: var(--accent)` plus `0 0 0 3px var(--accent-soft)` for inputs. The `<summary>` needs a visible ring; browsers give it one, do not remove it.
- **Responsive**: below 720px the rail becomes a top bar (already in `globals.css`). The 1a hero should drop its face stack and inline button below ~560px, keeping the label, name, meta and count. 1c's sticky header keeps name and "Add photos"; the download moves into the body.

## State

Nothing here needs a new store. What is new:

- `arrivingCount` — uploaded but not `ready`, per event. Already derivable server-side; today it is not surfaced. Feeds the 1a hero meta tail and the 1c pill.
- `lastActivityAt` vs `lastActiveAt` — the hero needs "is it live now", which is finer-grained than the existing `lastActiveAt` used by `metaFor`.
- `contributors: { actorId, displayName, handle, photoCount }[]` — the feed returns a contributor *count* today, not a list. New shape on `/api/events/<id>/photos`; must respect blocks.
- `selectedContributor: string | null` — client only.
- `sortMode: 'recent' | 'place'` — from the URL, not state.
- Upload queue state (`items`, `done`, `failed`, `stale`, `remaining`, `running`, `resumed`) — all exists in `useUploads`.
- `<details>` open state — DOM, not React, unless you need to force it open on failure.

## Design tokens

Straight from `apps/web/app/globals.css`:

| Token | Value |
| --- | --- |
| `--bg`, `--card` | `#fff` |
| `--line` | `#e3e6ea` |
| `--line-dashed` | `#d3d8de` |
| `--fg` | `#14171c` |
| `--dim` | `#5b6472` |
| `--accent` | `#1a5fd0` |
| `--accent-soft` | `#e8eefb` |
| `--scrim` | `linear-gradient(180deg, rgba(255,255,255,.62), rgba(255,255,255,.88))` |
| danger | `#b3261e` |

New values these designs introduce — add as tokens rather than literals:

| Purpose | Value |
| --- | --- |
| Interior hairline (inside a bordered container) | `#eef1f4` |
| Segmented-control track | `#f4f6f8` |
| Upload bar second stripe | `#3d7ade` |
| Debossed numeral ink | `rgba(20,23,28,.22)` |
| Deboss highlight / shade | `0 1px 0 rgba(255,255,255,.8)`, `0 -1px 1px rgba(20,23,28,.14)` |
| Brand-card scrim (1b) | `linear-gradient(180deg, rgba(255,255,255,.34), rgba(255,255,255,.78))` |
| Avatar tints (stand-ins) | `#f3e2e3`/`#8d5f63`, `#e2ece6`/`#4f7a68` |

Mark palette (from `Mark.tsx`, unchanged): `#ffb3b8`, `#9db2f0`, `#a5dcc6`, and the lenses `#c79ad9`, `#f3b584`, `#6fb6c4`, `#b084c5`.

**Type**: body `16px/1.5 -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`. Sizes used above: 26 / 24 / 22 / 20 / 18 / 17 / 16.5 / 15 / 14 / 13.5 / 13 / 12.5 / 11. Monospace `ui-monospace, Menlo, monospace` for links, filenames and codes. Garet 300 for the wordmark — and, if 1b is accepted, for card numerals.

**Radii**: 999 (pills, bars) · 20 (auth card, 1b card) · 16 (aside, 1a hero) · 14 (panels, rows container, details) · 12 (inputs, aside rows) · 10 (buttons) · 8 (tiles, rail rows) · 6 (native tiles).

**Spacing**: 2 · 3 · 4 · 6 · 8 · 10 · 12 · 14 · 16 · 18 · 20 · 22 · 24 · 26 · 28 · 30 · 36 · 40 · 56.

## Assets

- `fonts/garet-book.woff2` — copied from `apps/web/public/fonts/garet-book.woff2`. Already in the repo; do not re-add. It is declared at `font-weight: 300` because its `usWeightClass` is 300, and thickened with `-webkit-text-stroke: 0.045em` rather than synthetic bold. If a Garet Medium is ever licensed, the stroke comes off.
- **The mark** — inline SVG from `apps/web/app/components/Mark.tsx`, geometry checked against `apps/mobile/assets/icon.svg` by `brand.test.ts`. Use the component; do not hand-draw it. The prototypes inline a copy with distinct `clipPath` ids only because they are static files.
- **Photographs** — none. Every image is a striped placeholder; supply real signed URLs. `<picture>` with AVIF/WebP `<source>`s and a JPEG `<img>` fallback, as `PhotoTile` does today: the encoding is in the URL, never negotiated at the edge.
- **Icons** — none added. The only icon in the web client is the search glyph in `LoginScreen`; the `▾` and `＋` above are text characters. If you want real icons, that is a decision for the codebase, not this design.

## Files

In this bundle:

- `Parea — Current UI.dc.html` — the recreation baseline (web Home, Create, Event, Find, You; native Events tab, event screen, share sheet).
- `Parea — Explorations.dc.html` — turn 1: options `1a`, `1b`, `1c`. Anchors `#1a`, `#1b`, `#1c` scroll to each.
- `fonts/garet-book.woff2`, `ios-frame.jsx` (device bezel used by the native screens; a prototype-only prop).

Open either file directly in a browser.

Source files these were built from — read them before changing anything:

| Area | Files |
| --- | --- |
| Shell and nav | `apps/web/app/components/{Shell,Rail,Mark,InvitesBadge,SiteFooter}.tsx` |
| Home | `apps/web/app/events/page.tsx`, `app/components/{EventCard,MosaicTile}.tsx`, `packages/cards/src/index.ts` |
| Event view | `apps/web/app/components/{EventView,PhotoTile,PhotoLightbox}.tsx`, `app/event/[id]/page.tsx` |
| Create | `apps/web/app/page.tsx`, `packages/autoselect/src/when.ts` |
| You / auth | `apps/web/app/components/{AccountView,Avatar,EditProfile,SignIn,LoginScreen}.tsx` |
| Styles | `apps/web/app/globals.css` |
| Native counterparts | `apps/mobile/App.tsx`, `apps/mobile/src/{Events,CreateEvent}.tsx` |

## Open questions

1. **Hero fallback** on a quiet week — most-recently-added-to, or no hero at all?
2. **Garet on numerals** (1b) — accept the extension beyond the wordmark, or keep Garet wordmark-only and use the system face at 600?
3. **1b contributor treatment** — the mark plus a sentence, or the row of lens circles?
4. **Contributor list on the feed** — new field on `/api/events/<id>/photos`, or a separate endpoint? It changes what a leaked link exposes about who was there, so it wants the same scrutiny `authorize()` gets.
