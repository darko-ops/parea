# Handoff: Parea photo detail — a page, not a dialog (2c)

## Overview
Replaces the single-photo lightbox (`apps/web/app/components/PhotoLightbox.tsx`) with a real route: **`/event/<eventId>/p/<photoId>`**. Today a photo opens in a 720px white card over an 82% black scrim, where the photograph is bounded by the card, there is no way to reach the next photo, nothing states who added it or when, and `Report` / `Block this person` sit in the open at the same visual weight as a comment.

The page keeps the rail and the album's warm surface, so you never lose the album you are in; the photograph is the largest thing on it; who added it and when is stated under it; a filmstrip and `← →` move through the album; and the safety actions move behind `···` with their current wording and ownership logic unchanged.

The decisive reason for a page over a dialog: **a single photo becomes linkable.** "Look at this one" is a URL, Back returns to the gallery, and the browser's own history does the work that `onClose` does today.

## About the Design Files
`2c-photo-page.html` is a **design reference created in HTML** — a prototype of intended look and behaviour, not production code to copy. Recreate it in `apps/web` using its existing environment: Next.js App Router, server components, class-based CSS in `app/globals.css`, and the existing pieces (`PhotoComments`, `useImageFailure`, `Menu`, `Faces`, `ago()` from `@parea/cards`). The prototype uses inline styles only because the prototyping environment requires it; in the codebase these belong as classes and tokens in `globals.css`, as today.

## Fidelity
**High-fidelity.** Colours, type sizes, radii, gaps and paddings are final and listed below. The photograph, its neighbours in the filmstrip, and the avatars are striped gradient placeholders — the only thing to substitute.

## Screens / Views

### `/event/<eventId>/p/<photoId>` — the photo page
A server component beside the album page, sharing its layout and rail. Warm `#fbf8f4` surface throughout.

**Header** — `padding:18px 28px 14px; display:flex; align-items:center; gap:14px`:
- `‹` back, 34px hit area, `color:#5b6472`, `margin-left:-6px` so the glyph optically aligns with the content edge.
- `Back to **Naxos, September**` at `14px; color:#8a8378`, the album name `#14171c/600`, linking to the album's Photos tab. It is a real link, not a history call, so the page survives a cold load from a shared URL.
- Right side: position `7 of 214` at `13px; color:#8a8378`, then `←` and `→` as 34px outlined buttons (`border:1px solid #e4ded4; radius:10px`). They are `<a>` elements pointing at the neighbouring photo ids — prefetched, so paging feels instant — and disabled-looking (`opacity:.4`, `aria-disabled`) at either end of the album.

**Body** — `padding:0 28px 34px; display:flex; gap:28px; align-items:flex-start`.

**Left column** (`flex:1`, `gap:14px`):
1. **The photograph** — `height:560px; border-radius:16px`, `object-fit:contain` inside its box so nothing is cropped, centred, with the box's own background `#f2ede5` for photos that do not fill it. On viewports taller than ~1000px let it grow to `min(62vh, 720px)`.
2. **Attribution row** — 36px avatar, then `**Demetri** added this` at `15px` with `Friday 14 March, 21:40 · 4 days ago` beneath at `12.5px; color:#8a8378` (exact capture time from EXIF where present, else upload time — label it `Added` in that case rather than implying a capture time). Right side: `Download` as an outlined 13.5px/600 button, then `···` (36px, outlined, `color:#5b6472`).
3. **Filmstrip** — `display:flex; gap:8px; overflow-x:auto; padding-top:4px`. Thumbnails 56×56, `radius:8px`, neighbours at `opacity:.55`, the current one at full opacity with `box-shadow:0 0 0 2px #4e63a8`. Order matches the gallery's order; it scrolls the current thumbnail into the middle on load (use `scrollLeft` arithmetic, never `scrollIntoView`).

**Right column** (`width:352px; flex:none; gap:20px`):
1. **Who is in it** — overlapping 26px avatars (`margin-left:-8px`, `box-shadow:0 0 0 2px #fbf8f4`) then `Sam, Anya and Maya are in this one` at `13px; color:#5b6472`. Render only when the data exists — this is tags/mentions, not face detection; if there is no such data yet, omit the block entirely rather than showing an empty state (and say so in the ticket, since it may need building).
2. **Comments** — `3 comments` as an uppercase label (`12px/600; letter-spacing:.06em; color:#8a8378`), then messages: 30px avatar, `**Anya** · 3 days ago` at `12.5px; color:#8a8378`, body `14px/1.5`. This is `PhotoComments` — the same records as the event conversation, filtered by `photoId` — with its list no longer truncated, since the page has the room the dialog did not.
3. **Composer** — `border:1px solid #e4ded4; background:#fff; radius:12px; padding:11px 13px; 14px`, placeholder `Say something about this one…` (replacing `Comment on this photo…`). Under it `Also appears in the album conversation.` at `12px; color:#8a8378` — the existing note, shortened — and a filled `Post` button (`#4e63a8`, `8px 15px`, `radius:10px`). Keep today's behaviour: Enter posts, the draft survives a failed request, and the composer is absent when `canPost` is false.

**The `···` menu** — this is where the safety actions go, and the ownership split from `PhotoLightbox` is preserved exactly:
- **Your own photo:** `Remove my photo`, with `Yours. Nobody has to approve this.` as the item's own note. No confirmation step. On success, navigate to the neighbouring photo (or back to the album if it was the only one) — replacing today's `onChanged()` + `onClose()`.
- **Someone else's:** `That's me — take it down`, `Report`, then `Block this person`, which still requires the second press before it fires (`Block — hide all their photos`). Keep the three completion messages verbatim; show them as an inline confirmation on the page where the menu was, not a toast that can be missed. A block still refreshes the album behind the page.
- Also in the menu: `Copy link` (the page's own URL) and `Download`, so the header button has a keyboard-reachable twin.

Guideline 1.2 requires these be reachable, not prominent — one press of a visible `···` next to the photo satisfies that. Do not bury them behind a submenu or a second page.

**Failed image** — keep `useImageFailure`. The photo box holds its 560px height and shows `This photo could not be loaded. The actions below still work.` centred at `15px; color:#5b6472` on `#f7f5f1` with a `1px dashed #ded6c9` border. Everything else on the page stays live: you do not need to see a photo to know it is of you, which is the whole reason the tile leading here stays clickable.

## Interactions & Behavior
- **Opening:** a gallery tile is an `<a href>` to this route. Keep the click handler only to skip navigation while selection mode is active.
- **Paging:** `←`/`→` keys and the on-screen buttons navigate to the neighbour's route. Preload the next and previous full-size images on mount so paging does not flash. Swipe left/right on touch.
- **Closing:** `Esc` and `‹` both go back to the album's Photos tab. From a cold load (shared link), that is a normal link, so it works with no history.
- **Focus:** on load, focus moves to the photo's container (`tabindex="-1"`), so keyboard paging works immediately without trapping focus the way a modal must. Visible ring everywhere: `outline:3px solid #4e63a8; outline-offset:2px`.
- **Transitions:** none on navigation between photos beyond the image swap — no crossfade; the filmstrip's active ring moves instantly. Menus fade `120ms ease`.
- **Responsive:** below 1100px the right column moves beneath the photo at full width, filmstrip above it; below 720px the rail becomes the existing top bar, photo height `min(58vh, 420px)`, the composer sticks to the bottom of the viewport, and `← →` are swipe-only with the position label kept in the header.
- **Metadata:** `generateMetadata` per photo — album name plus contributor as the title, the photo as `og:image` — since the URL is now shareable. Respect the album's access policy: an unauthorised viewer gets the album's existing gate, not a 404 that leaks existence.

## State Management
- Route params (`eventId`, `photoId`) replace the `openPhoto` state in `EventView`; delete that state and the `PhotoLightbox` mount.
- Server-loaded per page: the photo (full URL, contributor, capture/upload time, `mine`), its neighbour ids and index within the album ordering, the album's name and id, `canPost`, and this photo's messages.
- Client state, unchanged in spirit: `draft` and `posting` (in `PhotoComments`), plus `busy`/`done`/`error`/`confirming` for the safety actions, which move with them into the menu.
- `PhotoLightbox.tsx` is deleted; `PhotoComments.tsx` survives with its truncation and its `photo-thread` framing removed (the page provides the frame). Keep the module comment explaining that a photo comment is a message with a `photoId` — it is still the reason this works.

## Design Tokens
```
--accent: #4e63a8      /* muted logo blue — was #1a5fd0 */
--accent-soft: #eceffb
--page-warm: #fbf8f4   /* the surface, shared with the album page */
--photo-bed: #f2ede5   /* behind a photo that does not fill its box */
--line: #e4ded4        /* control borders */
--hairline: #eee7dd
--line-dashed: #ded6c9
--dim: #5b6472
--dim-warm: #8a8378
--fg: #14171c
```
Pastels only in avatars (`#ffb3b8 / #9db2f0 / #a5dcc6 / #f3b584`, overlaps `#c79ad9`, `#6fb6c4`, `#b084c5`) and the filmstrip's active ring in accent. No dark scrim anywhere — the page replaces it.

Radii: 16px photo · 12px composer · 10px buttons · 8px thumbnails · 999px avatars. Spacing: 3/4/8/9/10/11/12/14/16/18/20/26/28/34. Type: system stack; Garet 300 uppercase on the wordmark only. Scale: 15 attribution · 14.5/14 body, comments, composer · 13.5 buttons · 13 metadata and the who-is-in-it line · 12.5 comment meta and secondary · 12 uppercase labels and the composer note.

Shadows: none, except `0 0 0 2px #4e63a8` on the active thumbnail and `0 0 0 2px #fbf8f4` rings on overlapped avatars.

## Assets
- `garet-book.woff2` — bundled; same file as `apps/web/public/fonts/garet-book.woff2`.
- Photograph, thumbnails, avatars — placeholders; substitute signed URLs from `imageSrc()` / `avatarUrl()`.
- No new icons. `←`, `→`, `‹`, `↓`, `···` are text glyphs, as today.

## Files
- `2c-photo-page.html` — the design. **This is the reference to build from.**
- `Parea Photo.dc.html` — the full design document: today's dialog recreated as `#1a` (someone else's photo) and `#1b` (your own, plus the failed-image state), and the three rejected alternatives for context.
- `Parea Rail.dc.html` — the rail with the muted accent.
- `garet-book.woff2`.

Source files this design touches: **new** `app/event/[id]/p/[photoId]/page.tsx`; **modified** `app/components/EventView.tsx` (tiles become links, lightbox state removed), `PhotoComments.tsx`, `Menu.tsx`, `app/globals.css` (`.lightbox*` rules deleted); **deleted** `PhotoLightbox.tsx`. Update the tests that assert the dialog to assert the route instead, rather than working around them.
